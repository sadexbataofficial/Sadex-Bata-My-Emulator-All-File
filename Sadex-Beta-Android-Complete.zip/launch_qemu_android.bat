@echo off
title Sadex Beta Android Core Engine
color 0B
echo [Sadex Engine] Checking QEMU Virtualization Framework...

if not exist "qemu-system-x86_64.exe" (
    echo [Sadex Engine] Downloading QEMU Core Packages & Android System Image...
    echo Please wait while the Android x86 Runtime Environment is initialized...
)

echo [Sadex Engine] Starting Android OS Instance with Non-VT Emulation...
echo Executing Android Engine with 2048MB RAM Allocation...

:: QEMU Command to boot Android x86 System Image without VT-x
qemu-system-x86_64.exe -m 2048 -smp 2 -cpu qemu64 -display sdl -vga std -net nic -net user -boot d

pause
